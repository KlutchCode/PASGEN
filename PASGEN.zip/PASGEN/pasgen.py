import os
import random
from tkinter import *

alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890`~!@#$%^&*()-=_+[]{}\|;:",<.>/?'

window = Tk()
window.title('PASGEN')
window.resizable(False, False)

canvas = Canvas(window, width=800, height=100)
canvas.pack()

output = "".join(random.sample(alphabet, len(alphabet)))
canvas.create_text(400, 50, text=output, fill='#000000', font=('arial', 11))

window.clipboard_append(output)

if os.path.exists('log.txt'):
    write = open('log.txt', 'a').write('blank | ' + output + '\n')

else:
    create = open('log.txt', 'w+')
    write = open('log.txt', 'a').write('blank | ' + output + '\n')

window.mainloop()